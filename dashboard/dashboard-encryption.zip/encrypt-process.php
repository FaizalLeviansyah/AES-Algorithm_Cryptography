<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../config.php'; // Menggunakan path absolut untuk include

if (empty($_SESSION['username'])) {
    $_SESSION['encrypt_message'] = "Sesi tidak valid. Silakan login ulang.";
    $_SESSION['encrypt_message_type'] = "error";
    header('Location: enkripsi.php');
    exit;
}

// Periksa apakah variabel koneksi adalah '$connect' atau '$conn'
// Ganti semua '$conn' di bawah ini menjadi '$connect' jika nama variabel di config.php adalah '$connect'
if (!isset($conn) && isset($connect)) {
    $conn = $connect; // Alias untuk konsistensi dengan sisa skrip ini
}

define('PBKDF2_HASH_ALGORITHM', 'sha256');
define('PBKDF2_ITERATIONS', 10000);
define('SALT_BYTE_SIZE', 16);
define('IV_BYTE_SIZE', 16);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['encrypt_now_button'])) {

    $username = $_SESSION['username'];
    $originalFile = $_FILES['file'];
    $password = $_POST['pwdfile'];
    $desc = trim($_POST['desc']);
    $algorithm = $_POST['algorithm'];

    if (empty($password) || $originalFile['error'] !== UPLOAD_ERR_OK || empty($algorithm)) {
        $_SESSION['encrypt_message'] = "Data tidak lengkap atau terjadi kesalahan upload file.";
        $_SESSION['encrypt_message_type'] = "error";
        header('Location: enkripsi.php');
        exit;
    }

    $originalName = basename($originalFile['name']);
    $raw_content = file_get_contents($originalFile['tmp_name']);

    $cipher = ($algorithm === 'AES-128-CBC') ? 'aes-128-cbc' : 'aes-256-cbc';
    $key_length = ($algorithm === 'AES-128-CBC') ? 16 : 32;

    $salt = random_bytes(SALT_BYTE_SIZE);
    $key = hash_pbkdf2(PBKDF2_HASH_ALGORITHM, $password, $salt, PBKDF2_ITERATIONS, $key_length, true);
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));

    $start_time = microtime(true);
    $ciphertext = openssl_encrypt($raw_content, $cipher, $key, OPENSSL_RAW_DATA, $iv);
    $duration = round((microtime(true) - $start_time) * 1000, 4);

    if ($ciphertext === false) {
        $_SESSION['encrypt_message'] = "Enkripsi gagal. Detail: " . openssl_error_string();
        $_SESSION['encrypt_message_type'] = "error";
        header('Location: enkripsi.php');
        exit;
    }

    // Hanya simpan ciphertext murni di file untuk kompatibilitas OpenSSL CLI
    $final_data_to_save = $ciphertext;

    $enc_filename = 'enc_' . time() . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $originalName) . '.enc';
    $destinationFolder = __DIR__ . '/hasil_enkripsi/';
    if (!is_dir($destinationFolder)) {
        mkdir($destinationFolder, 0755, true);
    }
    $destinationPath = $destinationFolder . $enc_filename;
    
    if(file_put_contents($destinationPath, $final_data_to_save) === false) {
        $_SESSION['encrypt_message'] = "Gagal menyimpan file ke server.";
        $_SESSION['encrypt_message_type'] = "error";
        header('Location: enkripsi.php');
        exit;
    }
    
    // PERBAIKAN: Hitung hash dari file terenkripsi, bukan plaintext
    $hash = hash_file('sha256', $destinationPath);
    $size_kb = round(filesize($destinationPath) / 1024, 2);
    $now = date('Y-m-d H:i:s');
    $salt_hex = bin2hex($salt);
    $iv_hex = bin2hex($iv);
    $kdf_iterations = PBKDF2_ITERATIONS;
    $db_path = 'dashboard/hasil_enkripsi/' . $enc_filename;

    // PERBAIKAN: Hapus kolom 'password' dan tambahkan 'sumber_id_file' jika Anda menggunakannya
    // Query ini disesuaikan dengan struktur tabel terbaru yang kita sepakati
    $stmt = $conn->prepare("INSERT INTO file (
        username, file_name_source, file_name_finish, file_url, file_size_kb, 
        alg_used, process_time_ms, operation_type, hash_check, status, 
        keterangan, password_salt_hex, file_iv_hex, kdf_iterations, tgl_upload, tgl_encrypt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // PERBAIKAN: String tipe data disesuaikan, dan variabel password dihapus
    $stmt->bind_param("ssssdsdssisssiss",
        $username, 
        $originalName, 
        $enc_filename, 
        $db_path, 
        $size_kb,
        $algorithm,     // s
        $duration,      // d
        $op = 'enkripsi_awal', // s
        $hash,          // s
        $st = '1',      // s
        $desc,          // s
        $salt_hex,      // s
        $iv_hex,        // s
        $kdf_iterations,// i
        $now,           // s
        $now            // s
    );

    if ($stmt->execute()) {
        $_SESSION['encrypt_message'] = "File '" . htmlspecialchars($originalName) . "' berhasil dienkripsi!";
        $_SESSION['encrypt_message_type'] = "success";
        header('Location: dekripsi.php'); // Redirect ke halaman dekripsi agar bisa langsung melihat hasilnya
        exit();
    } else {
        $_SESSION['encrypt_message'] = "Gagal menyimpan ke database: " . $stmt->error;
        $_SESSION['encrypt_message_type'] = "error";
        if(file_exists($destinationPath)) unlink($destinationPath); // Cleanup file
        header('Location: enkripsi.php');
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>