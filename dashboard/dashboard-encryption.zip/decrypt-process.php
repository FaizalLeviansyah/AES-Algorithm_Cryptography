<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../config.php';

// Asumsikan auth_check.php sudah dijalankan atau ada validasi sesi di sini
if (empty($_SESSION['username'])) {
    die("Akses tidak sah. Silakan login terlebih dahulu.");
}

// Validasi input awal
if (!isset($_GET['id_file']) || empty($_POST['pwdfile_decrypt'])) {
    $_SESSION['dekripsi_message'] = "Permintaan tidak valid. ID file atau password tidak ada.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: dekripsi.php");
    exit;
}

$id_file = (int)$_GET['id_file'];
$password = $_POST['pwdfile_decrypt'];

// 1. Ambil data file dari database menggunakan prepared statement
$stmt = $connect->prepare("SELECT file_url, alg_used, file_name_source, password_salt_hex, file_iv_hex, kdf_iterations FROM file WHERE id_file = ? AND username = ? AND status = '1'");
if (!$stmt) {
    die("Error saat menyiapkan query: " . $connect->error);
}
$stmt->bind_param("is", $id_file, $_SESSION['username']); // Hanya bisa dekripsi file sendiri
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['dekripsi_message'] = "File tidak ditemukan, sudah didekripsi, atau Anda tidak memiliki izin.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: dekripsi.php");
    exit;
}
$row = $result->fetch_assoc();
$stmt->close();

// 2. Persiapan parameter kriptografi
$file_path_encrypted_physical = __DIR__ . '/../' . $row['file_url']; // Path fisik yang lebih robust
$alg_from_db = $row['alg_used'];
$iv_hex_from_db = $row['file_iv_hex'];
$salt_hex_from_db = $row['password_salt_hex'];
$kdf_iterations_from_db = (int)$row['kdf_iterations'];
$original_name = $row['file_name_source'];

// Periksa apakah semua parameter kriptografi ada
if (empty($alg_from_db) || empty($iv_hex_from_db) || empty($salt_hex_from_db)) {
    $_SESSION['dekripsi_message'] = "Gagal dekripsi: Data parameter kriptografi (salt/iv) tidak lengkap di database.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: decrypt-file.php?id_file=" . urlencode($id_file));
    exit;
}

if (!file_exists($file_path_encrypted_physical)) {
    $_SESSION['dekripsi_message'] = "Gagal dekripsi: File terenkripsi tidak ditemukan di server.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: decrypt-file.php?id_file=" . urlencode($id_file));
    exit;
}

// Tentukan cipher dan panjang kunci dari `alg_used`
$cipher = strtolower($alg_from_db); // 'aes-128-cbc' atau 'aes-256-cbc'
$key_length = ($alg_from_db === 'AES-128-CBC') ? 16 : 32;

$salt = hex2bin($salt_hex_from_db);
$iv = hex2bin($iv_hex_from_db);
$key = hash_pbkdf2('sha256', $password, $salt, $kdf_iterations_from_db, $key_length, true);

// 3. Proses dekripsi dan ukur waktu
$encrypted_data = file_get_contents($file_path_encrypted_physical);

$start_time_decrypt = microtime(true);
$decrypted_data = openssl_decrypt($encrypted_data, $cipher, $key, OPENSSL_RAW_DATA, $iv);
$end_time_decrypt = microtime(true);
$process_time_ms = round(($end_time_decrypt - $start_time_decrypt) * 1000, 4); 

if ($decrypted_data === false) {
    $_SESSION['dekripsi_message'] = "Dekripsi gagal. Kemungkinan password salah atau file rusak.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: decrypt-file.php?id_file=" . urlencode($id_file));
    exit;
}

// 4. Simpan hasil dekripsi
$output_name = 'dec_' . time() . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $original_name);
$output_dir = __DIR__ . '/hasil_dekripsi/'; // Path fisik: dashboard/hasil_dekripsi/
$output_path_physical = $output_dir . $output_name;

if (!is_dir($output_dir)) {
    mkdir($output_dir, 0755, true);
}

if (file_put_contents($output_path_physical, $decrypted_data) === false) {
    $_SESSION['dekripsi_message'] = "Gagal menyimpan file hasil dekripsi ke server.";
    $_SESSION['dekripsi_message_type'] = "error";
    header("Location: dekripsi.php");
    exit;
}

// 5. Update status dan metadata di database dengan lengkap
$now = date('Y-m-d H:i:s');
$db_path_decrypted = 'dashboard/hasil_dekripsi/' . $output_name;
$fileSizeKB_decrypted = round(filesize($output_path_physical) / 1024, 2);
$hash_decrypted = hash_file('sha256', $output_path_physical);
$new_status = '2';
$new_operation_type = 'dekripsi';

// Query UPDATE yang lebih lengkap
$update_stmt = $connect->prepare("UPDATE file SET 
                                    status = ?, 
                                    tgl_decrypt = ?, 
                                    tgl_upload = ?, -- Update tgl_upload sebagai waktu operasi terakhir
                                    file_name_finish = ?, 
                                    file_url = ?,
                                    file_size_kb = ?,
                                    hash_check = ?,
                                    operation_type = ?,
                                    process_time_ms = ?
                                WHERE id_file = ?");

if (!$update_stmt) {
    die("Error saat menyiapkan query update: " . $connect->error);
}

$update_stmt->bind_param("sssssdsidi", 
    $new_status, 
    $now, 
    $now, 
    $output_name, 
    $db_path_decrypted, 
    $fileSizeKB_decrypted,
    $hash_decrypted,
    $new_operation_type,
    $process_time_ms,
    $id_file
);

if ($update_stmt->execute()) {
    $_SESSION['dekripsi_message'] = "File '" . htmlspecialchars($original_name) . "' berhasil didekripsi.";
    $_SESSION['dekripsi_message_type'] = "success";

    // Opsional: Hapus file terenkripsi yang lama setelah berhasil didekripsi dan diupdate
    // unlink($file_path_encrypted_physical); // Hati-hati dengan ini, lakukan jika Anda yakin
} else {
    $_SESSION['dekripsi_message'] = "Gagal mengupdate status file di database: " . $update_stmt->error;
    $_SESSION['dekripsi_message_type'] = "error";
    if (file_exists($output_path_physical)) {
        unlink($output_path_physical); // Cleanup file dekripsi jika update DB gagal
    }
}
$update_stmt->close();

// 6. Redirect ke halaman daftar file
header("Location: dekripsi.php");
exit;
?>